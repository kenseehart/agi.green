## Attributions - thank you!

- [Development co-author: ChatGPT (GPT4), Github copilot](https://www.openai.com)
- [Send icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/send)
- [Split Views by Nguyen Huu Phuoc](https://htmldom.dev/create-resizable-split-views/)

